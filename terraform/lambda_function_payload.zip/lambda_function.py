import boto3
import json
import os

def lambda_handler(event, context):
    print("Received EC2 instance stopped event:")
    print(json.dumps(event, indent=2))
    
    # Get the instance ID to start from the environment variable
    instance_id_to_start = os.environ['START_INSTANCE_ID']
    print(f"Attempting to start instance: {instance_id_to_start}")
    
    try:
        ec2_client = boto3.client('ec2')
        response = ec2_client.start_instances(
            InstanceIds=[instance_id_to_start]
        )
        print(f"Successfully triggered start for instance {instance_id_to_start}. Response: {json.dumps(response, indent=2)}")
        return {
            'statusCode': 200,
            'body': json.dumps(f'Successfully started instance {instance_id_to_start}')
        }
    except Exception as e:
        print(f"Error starting instance {instance_id_to_start}: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error starting instance {instance_id_to_start}: {str(e)}')
        }
